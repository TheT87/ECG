# ECG_Exercise2
TU Dresden, "Introduction to Computer Graphics" - Exercise 2

Zdravko: 2.1.1 (DDA), 2.1.2 (Bresenham)
Lucas: 2.2.1 (recursive filling), 2.2.2 (non-recursive filling)
Gregor: Additional tasks (Rectangle, Circle)
