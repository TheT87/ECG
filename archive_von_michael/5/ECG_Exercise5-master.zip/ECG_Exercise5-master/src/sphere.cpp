#include "sphere.h"
#include "utils.h"


sphere::sphere():radius(1.0f),sqr_radius(1.0f)
{
	center.zeros();
}

sphere::sphere(float cx, float cy, float cz, float r):center(cx,cy,cz),radius(r)
{
	sqr_radius=r*r;
}

sphere::sphere(const tiny_vec<float,3>& c, float r):center(c),radius(r)
{
	sqr_radius=r*r;
}

void sphere::set_radius(float r)
{
	radius = r;
	sqr_radius = r*r;
}

void sphere::calc_normal(intersection_info* hit)const 
{
	tiny_vec<float,3> nml = hit->get_location()-center;
	nml.normalize();
	
	hit->set_normal(nml);
}

std::pair<tiny_vec<float,3>, tiny_vec<float,3> > sphere::calc_bounds()
{
	return std::make_pair(center-radius,center+radius);
}

bool sphere::closest_intersection(intersection_info* hit, float min_lambda, primitive* dont_hit)
{
	//student begin
	//see task 1.2.1
	if (this == dont_hit) return false;

	float a = pow(hit->get_incoming_ray().get_direction().length(), 2);
	float b = 2 * dot(hit->get_incoming_ray().get_direction(), hit->get_incoming_ray().get_origin() - center);
	float c = pow((hit->get_incoming_ray().get_origin() - center).length(), 2) - pow(radius, 2);
	float result_array[2] = { 0, 0 };
	int result_count = solve_real_quadratic<float>(a, b, c, result_array);

	if (result_count == 0) return false;

	float lambda;

	if (result_count == 1) lambda = result_array[0];
	else if (result_count == 2)
	{
		if (result_array[0] > 0 && result_array[1] > 0) lambda = std::min(result_array[0], result_array[1]);
		else if (result_array[0] < 0 && result_array[1] > 0) lambda = result_array[1];
		else if (result_array[0] > 0 && result_array[1] < 0) lambda = result_array[0];
	}

	if (lambda > min_lambda && lambda < hit->get_lambda())
	{
		hit->set_lambda(lambda);
		hit->set_object(this);
		calc_normal(hit);
		return true;
	}
	else return false;
	//student end
}

bool sphere::any_intersection(ray<float>& r,float min_lambda,float max_lambda, primitive* dont_hit)
{
	//student begin
	//see task 1.2.1
	if (this == dont_hit) return false;

	float a = pow(r.get_direction().length(), 2);
	float b = 2 * dot(r.get_direction(), r.get_origin() - center);
	float c = pow((r.get_origin() - center).length(), 2) - pow(radius, 2);
	float result_array[2] = { 0, 0 };
	int result_count = solve_real_quadratic<float>(a, b, c, result_array);

	if (result_count == 0) return false;

	for (int i = 0; i < result_count; i++)
	{
		if (result_array[i] > min_lambda && result_array[i] < max_lambda)
			return true;
	}
	
	return false;
	//student end

}
