#include "phong.h"
#include "utils.h"
	
tiny_vec<float,3> phong::shade_diffuse(intersection_info* hit, light_source *light)
{
	tiny_vec<float,3> col(0.0f,0.0f,0.0f);
	tiny_vec<float,3> attenuation = light->get_attenuation_factors(hit); 
		
	//student begin
	//see task 1.3.2

	tiny_vec<float, 3> normal = hit->get_normal();
	tiny_vec<float, 3> w_in = hit->get_direction_to_light();
	tiny_vec<float, 3> l_in = light->get_color();

	//first set col to the diffuse factor...
	col = get_diffuse();

	//...then multiply each component with the right side vector of the formula...
	col.x() *= (l_in * dot(w_in, normal)).x();
	col.y() *= (l_in * dot(w_in, normal)).y();
	col.z() *= (l_in * dot(w_in, normal)).z();
	
	//...and finally multiply with the light attentuation
	col *= attenuation;

	//student end

	return col;	


}

tiny_vec<float,3> phong::shade_specular(intersection_info* hit, light_source *light)
{
	tiny_vec<float,3> col(0.0f,0.0f,0.0f);
	tiny_vec<float,3> attenuation = light->get_attenuation_factors(hit); 
	
	
	//student begin
	//see task 1.3.2

	tiny_vec<float, 3> l_in = light->get_color();
	tiny_vec<float, 3> w_in = hit->get_direction_to_light();
	tiny_vec<float, 3> w_out = hit->get_direction_to_camera();
	tiny_vec<float, 3> normal = hit->get_normal();

	//calculating the reflection-vector (->silde 23)
	tiny_vec<float, 3> w_refl = 2 * dot(normal, w_in)*normal - w_in;

	//if the dot product is less than 0 the specular amount drops out
	if (dot(w_in, normal) >= 0) col = get_specular();
	else return col;

	//multiply each component with the "Phong" formnula times L_in

	float phong = pow(dot(w_out, w_refl), get_shininess());

	col.x() *= (l_in * phong).x();
	col.y() *= (l_in * phong).y();
	col.z() *= (l_in * phong).z();

	//multiplay with attenuation
	col *= attenuation;

	//student end

	return col;	


}