#include "blinn_phong.h"
#include "utils.h"



tiny_vec<float,3> blinn_phong::shade_specular(intersection_info* hit, light_source *light)
{
		
	tiny_vec<float,3> attenuation = light->get_attenuation_factors(hit); 
	tiny_vec<float,3> col(0.0f,0.0f,0.0f);
	//studen begin
	//see task 1.3.1

	tiny_vec<float, 3> l_in = light->get_color();
	tiny_vec<float, 3> w_in = hit->get_direction_to_light();
	tiny_vec<float, 3> w_out = hit->get_direction_to_camera();
	tiny_vec<float, 3> normal = hit->get_normal();

	//calculating the half vector between w_in and w_out
	tiny_vec<float, 3> w_half = (w_in + w_out) / ((w_in + w_out).length());

	//if the dot product is less than 0 the specular amount drops out
	if (dot(w_in, normal) >= 0) col = get_specular();
	else return col;

	//multiply each component with the "Phong" formnula times L_in

	float blinn_phong = pow(dot(w_half, normal), get_shininess());

	col.x() *= (l_in * blinn_phong).x();
	col.y() *= (l_in * blinn_phong).y();
	col.z() *= (l_in * blinn_phong).z();

	//multiplay with attenuation
	col *= attenuation;

	//student end

	return col;



	//student end
	return col;	

}

