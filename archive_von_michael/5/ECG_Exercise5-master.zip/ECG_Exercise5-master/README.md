# ECG_Exercise5
 TU Dresden, "Introduction to Computer Graphics" - Exercise 5
 
Note: buddha.obj should not be uploaded as a part of the solution
